# Suricata IDS Practical Lab

![Lab](https://img.shields.io/badge/type-hands--on%20lab-blue)
![Level](https://img.shields.io/badge/level-beginner-green)
![Tool](https://img.shields.io/badge/tool-Suricata-orange)
![License](https://img.shields.io/badge/license-MIT-lightgrey)

A beginner-friendly, copy/paste-ready lab that shows how to deploy **Suricata** as a network **Intrusion Detection System (IDS)**, write a custom detection rule, generate test traffic with **netcat**, and investigate the resulting alerts with `fast.log`, `eve.json`, `grep` and `jq`.

> **Authorized use only.** Run this lab only on virtual machines and networks you own or are explicitly authorized to test. The traffic script refuses non-private IP addresses by design.

## What you will learn

- Install and configure Suricata (`HOME_NET`, capture interface, rule files)
- Identify the correct network interface with `ip`
- Write and validate a custom detection rule
- Generate controlled traffic with netcat
- Trigger, read and analyze alerts like a SOC analyst
- Troubleshoot *No route to host*, *Connection refused*, wrong interface and missing alerts

## Lab topology

![Topology](docs/images/topology.png)

| Role | Placeholder | Example |
|---|---|---|
| Suricata Sensor VM | `<SURICATA_IP>` | 192.168.56.10 |
| Client VM | `<CLIENT_IP>` | 192.168.56.20 |
| Lab subnet | `<LAB_SUBNET>` | 192.168.56.0/24 |
| Capture interface | `<INTERFACE>` | enp0s8 |

Replace every `<PLACEHOLDER>` with your own values before running a command.

## Quick start

**On the Sensor VM**

```bash
git clone https://github.com/<YOUR_GITHUB_USERNAME>/suricata-ids-lab.git
cd suricata-ids-lab
chmod +x scripts/*.sh

./scripts/install_suricata.sh          # install Suricata, jq, netcat; deploy local.rules
ip -br a                               # find <INTERFACE> and <SURICATA_IP>
sudo nano /etc/suricata/suricata.yaml  # set HOME_NET, af-packet interface, rule-files
sudo suricata -T -c /etc/suricata/suricata.yaml -v   # expect: 0 rules failed
```

Terminal A (Sensor): start Suricata

```bash
sudo suricata -c /etc/suricata/suricata.yaml -i <INTERFACE>
```

Terminal B (Sensor): start the listener

```bash
./scripts/start_listener.sh 4444
```

Terminal C (Sensor): watch alerts

```bash
sudo tail -f /var/log/suricata/fast.log
```

**On the Client VM**

```bash
./scripts/generate_traffic.sh <SURICATA_IP> 4444
```

**Analyze (Sensor)**

```bash
sudo ./scripts/analyze_logs.sh
```

## Expected result

```text
10/05/2026-14:32:10.302911  [**] [1:1000002:1] LAB Netcat - Marker string SURICATA-LAB-TEST in payload [**] [Classification: A Network Trojan was detected] [Priority: 1] {TCP} 192.168.56.20:51234 -> 192.168.56.10:4444
```

More examples are in [`samples/`](samples/).

## Project structure

```text
suricata-ids-lab/
├── README.md
├── LICENSE
├── .gitignore
├── config/
│   └── suricata.yaml.example        # excerpt of the settings changed in the lab
├── rules/
│   └── local.rules                  # custom detection rules (SID 1000001-1000003)
├── scripts/
│   ├── install_suricata.sh          # install + deploy rules
│   ├── start_listener.sh            # netcat listener (sensor)
│   ├── generate_traffic.sh          # test traffic (client)
│   ├── analyze_logs.sh              # grep/jq summary report
│   └── reset_logs.sh                # empty logs between runs
├── samples/
│   ├── fast.log.sample
│   ├── eve-alert.sample.json
│   └── eve.sample.jsonl
├── docs/
│   ├── LAB_MANUAL.md                # full step-by-step lab
│   ├── CHEATSHEET.md                # command cheat sheet
│   ├── TROUBLESHOOTING.md           # common errors and fixes
│   ├── Suricata-IDS-Lab-Manual.docx
│   ├── Suricata-IDS-Lab-Manual.pdf
│   ├── Suricata-Command-Cheat-Sheet.pdf
│   └── images/topology.png
├── reports/
│   └── incident_report_template.md
├── screenshots/                     # your evidence (git-ignored contents)
└── logs/                            # runtime logs (git-ignored contents)
```

## Detection rules

| SID | Detects | Triggered by |
|---|---|---|
| 1000001 | TCP connection attempt (SYN) to port 4444 | `nc -zv <SURICATA_IP> 4444` |
| 1000002 | Marker string `SURICATA-LAB-TEST` in TCP payload | `printf 'SURICATA-LAB-TEST\n' \| nc <SURICATA_IP> 4444` |
| 1000003 | ICMP echo request | `ping <SURICATA_IP>` |

## Documentation

| Document | Description |
|---|---|
| [Lab manual (Markdown)](docs/LAB_MANUAL.md) | Complete lab with expected output and explanations |
| [Lab manual (PDF)](docs/Suricata-IDS-Lab-Manual.pdf) / [DOCX](docs/Suricata-IDS-Lab-Manual.docx) | Printable versions |
| [Cheat sheet](docs/CHEATSHEET.md) / [PDF](docs/Suricata-Command-Cheat-Sheet.pdf) | Commands at a glance |
| [Troubleshooting](docs/TROUBLESHOOTING.md) | No route to host, Connection refused, wrong interface, missing alerts |
| [Incident report template](reports/incident_report_template.md) | For the practical challenge |

## Skills demonstrated

Network intrusion detection, Suricata rule writing, Linux administration, traffic generation and packet-level troubleshooting, log analysis with `grep` and `jq`, and incident documentation.

## Troubleshooting in 30 seconds

| Symptom | Likely cause |
|---|---|
| `No route to host` | Wrong IP, VMs on different networks, or firewall reject |
| `Connection refused` | No listener on the port (rule 1000001 still fires) |
| No alerts | Wrong `<INTERFACE>`, rules not loaded, or rule not in `rule-files` |

See [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for the full guide.

## License

Released under the [MIT License](LICENSE). Replace `<YOUR_NAME>` in the license and `<YOUR_GITHUB_USERNAME>` in the clone URL before publishing.
